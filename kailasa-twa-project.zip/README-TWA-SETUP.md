# Kailasa — Build Your Own AAB (Step by Step)

No PWABuilder. No Bubblewrap. You own everything.

---

## Step 1: Unzip this into your K repo

Take the `twa/` folder and `.github/` folder from this zip.
Drop them into the root of your `jsingh2610/K` repo so it looks like:

```
K/
├── .github/workflows/build-aab.yml
├── twa/
│   ├── app/
│   ├── build.gradle
│   ├── settings.gradle
│   └── ...
├── index.html        ← your existing files
├── manifest.json
└── ...
```

Commit and push.

---

## Step 2: Find your keystore alias and passwords

Go to this folder on your laptop:

```
Downloads/Kailāsa - Google Play package/
```

Open the file called `signing-key-info`. It's a text file.
You'll see 3 things written there:

- **Alias** (something like `my-key-alias`)
- **Keystore password**
- **Key password**

Write these down. You need them in Step 4.

---

## Step 3: Convert your keystore to text

Open PowerShell on your laptop. Run this:

```powershell
cd "$env:USERPROFILE\Downloads\Kailāsa - Google Play package"
[Convert]::ToBase64String([IO.File]::ReadAllBytes("signing.keystore")) | Set-Clipboard
```

This copies a long text string to your clipboard. You need it in Step 4.

---

## Step 4: Add secrets to GitHub

1. Go to https://github.com/jsingh2610/K/settings/secrets/actions
2. Click "New repository secret" four times, adding:

| Name               | Value                                       |
|--------------------|---------------------------------------------|
| KEYSTORE_BASE64    | Paste what you copied in Step 3             |
| KEYSTORE_PASSWORD  | The keystore password from Step 2           |
| KEY_ALIAS          | The alias from Step 2                       |
| KEY_PASSWORD       | The key password from Step 2                |

---

## Step 5: Build your AAB

1. Go to https://github.com/jsingh2610/K/actions
2. Click "Build AAB" in the left sidebar
3. Click "Run workflow" → "Run workflow"
4. Wait ~3 minutes
5. Click the completed run → scroll down → download `kailasa-release`

That zip contains your AAB.

---

## Step 6: Upload to Play Console

1. Go to Play Console → Kailasa → Testing → Closed testing
2. Create new release
3. Upload the AAB
4. Done

---

## When do you need to do this again?

**Almost never.** Your web app updates deploy automatically through
Cloudflare Pages. The AAB is just the shell.

You only rebuild the AAB when:
- Play Console asks for a new version (bump `versionCode` in `twa/app/build.gradle`)
- You change your app icon
- You change your signing key

To bump version: open `twa/app/build.gradle`, change `versionCode 2` to `3`
(or whatever is next), commit, push, and run the workflow again.
